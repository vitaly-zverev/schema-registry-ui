require("./home/home.controller");
require("./config/config.controller");
require("./view/view.controller");
require("./export/export.controller");
require("./list/list.controller");
require("./new/new.controller");